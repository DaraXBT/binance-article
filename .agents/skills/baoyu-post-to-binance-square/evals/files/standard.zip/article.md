A short introduction.

## Market setup

![Market setup](images/01-slide.png)

#BTC #Crypto

A technical introduction.

## Architecture

### Data flow

- Validate input
- Compose the editor

> Review before publishing.

```typescript
const safe = true;
```

| Check | Result |
| --- | --- |
| Hashes | Verified |

![Architecture](images/01-slide.png)

#Bitcoin $BTC
